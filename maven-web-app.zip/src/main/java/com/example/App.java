package com.example;

public class App {
    public static String getMessage() {
        return "Hello from Java Web App!";
    }
}
